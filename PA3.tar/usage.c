#include <stdio.h>

/* A print statement that displays all legal commands */

void usage( ) {
	printf("Usage:\n");
	printf(" #	insert # into stack or queue\n");
	printf(" s	select STACK mode and display stack\n");
	printf(" q	select QUEUE mode and display queue\n");
	printf(" p	remove top of stack/head of queue and display\n");
	printf(" Q	Quit\n");
	printf(" ?	Display help\n");
}		//Kinda self explanatory (:
